const HEADER_RULE_ID = 1001;
const TRACKER_RULE_IDS = [2001, 2002, 2003, 2004];

const IRAN_BUILTIN_DOMAINS = [
  '*.ir', 'shaparak.ir', 'bmi.ir', 'mellatbank.com', 'bankmellat.ir', 'tejaratbank.ir',
  'bsi.ir', 'banksepah.ir', 'bpi.ir', 'sb24.ir', 'parsian-bank.ir', 'refah-bank.ir',
  'snapp.ir', 'tapsi.ir', 'digikala.com', 'divar.ir', 'sheypoor.com', 'aparat.com',
  'filimo.com', 'namava.ir', 'telewebion.com', 'rubika.ir', 'eitaa.com', 'bale.ai',
  'soroush-app.ir', 'igap.net', 'torob.com', 'emalls.ir', 'cafebazaar.ir', 'myket.ir',
  'iran.gov.ir', 'my.gov.ir', 'samanese.ir', 'tax.gov.ir', 'tamin.ir', 'adliran.ir'
];

async function updateDynamicRules(state) {
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [HEADER_RULE_ID, ...TRACKER_RULE_IDS]
    });
    const addRules = [];
    if (state.enabled && state.country && state.country.lang) {
      const langHeader = `${state.country.lang},${state.country.lang.split('-')[0]};q=0.9,en;q=0.8`;
      const excludedRequestDomains = (state.splitMode !== 'only_include')
        ? (state.bypassDomains || []).map(d => d.replace(/^\*\./, '').trim()).filter(Boolean)
        : [];
      const cond = { urlFilter: '*', resourceTypes: ['main_frame', 'sub_frame', 'xmlhttprequest', 'fetch', 'other'] };
      if (excludedRequestDomains.length > 0) cond.excludedRequestDomains = excludedRequestDomains;
      addRules.push({
        id: HEADER_RULE_ID,
        priority: 1,
        action: { type: 'modifyHeaders', requestHeaders: [{ header: 'Accept-Language', operation: 'set', value: langHeader }] },
        condition: cond
      });
    }
    if (state.enabled && state.blockTrackers !== false) {
      ['google-analytics.com', 'doubleclick.net', 'hotjar.com', 'fpjs.io'].forEach((domain, idx) => {
        addRules.push({
          id: TRACKER_RULE_IDS[idx],
          priority: 2,
          action: { type: 'block' },
          condition: { urlFilter: `||${domain}^`, resourceTypes: ['script', 'xmlhttprequest', 'ping'] }
        });
      });
    }
    if (addRules.length > 0) await chrome.declarativeNetRequest.updateDynamicRules({ addRules });
  } catch (err) {}
}

function updateWebRTC(enabled) {
  try {
    if (chrome.privacy && chrome.privacy.network && chrome.privacy.network.webRTCIPHandlingPolicy) {
      chrome.privacy.network.webRTCIPHandlingPolicy.set({
        value: enabled ? 'disable_non_proxied_udp' : 'default'
      });
    }
  } catch (err) {}
}

function buildPacScript(state) {
  if (!state.enabled || state.ipMode !== 'direct_proxy' || !state.proxy || !state.proxy.host) {
    return null;
  }
  const scheme = (state.proxy.scheme || 'socks5').toUpperCase();
  const pacProto = scheme === 'SOCKS5' ? 'SOCKS5' : (scheme === 'HTTPS' ? 'HTTPS' : 'PROXY');
  const targetProxyStr = `${pacProto} ${state.proxy.host.trim()}:${parseInt(state.proxy.port, 10) || 1080}`;
  const splitMode = state.splitMode || 'all_except_bypass';
  const bypassArr = JSON.stringify((state.bypassDomains || []).map(d => d.toLowerCase().trim()).filter(Boolean));
  const includeArr = JSON.stringify((state.includeDomains || []).map(d => d.toLowerCase().trim()).filter(Boolean));

  return `function matchDomain(host, list) {
    host = host.toLowerCase();
    for (var i = 0; i < list.length; i++) {
      var rule = list[i];
      if (rule === "*.ir" || rule === ".ir") {
        if (dnsDomainIs(host, ".ir") || host === "ir") return true;
      } else {
        var clean = rule.replace(/^\\*\\./, "");
        if (host === clean || dnsDomainIs(host, "." + clean)) return true;
      }
    }
    return false;
  }
  function FindProxyForURL(url, host) {
    if (isPlainHostName(host) || host === "127.0.0.1" || host === "localhost") return "DIRECT";
    var splitMode = "${splitMode}";
    var bypassList = ${bypassArr};
    var includeList = ${includeArr};
    if (splitMode === "only_include") {
      return matchDomain(host, includeList) ? "${targetProxyStr}; DIRECT" : "DIRECT";
    } else {
      return matchDomain(host, bypassList) ? "DIRECT" : "${targetProxyStr}; DIRECT";
    }
  }`;
}

async function applyFullState(state) {
  const pacData = buildPacScript(state);
  if (pacData) {
    chrome.proxy.settings.set({
      value: { mode: 'pac_script', pacScript: { data: pacData } },
      scope: 'regular'
    });
  } else {
    chrome.proxy.settings.clear({ scope: 'regular' });
  }
  await updateDynamicRules(state);
  updateWebRTC(state.enabled);
  return { ok: true, mode: state.ipMode || 'system_vpn' };
}

async function fetchChocolate4UIranRules() {
  try {
    const url = 'https://raw.githubusercontent.com/Chocolate4U/Iran-v2ray-rules/release/iran.txt';
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 7000);
    const resp = await fetch(url, { signal: ctrl.signal });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const text = await resp.text();
    const parsed = text.split('\n')
      .map(l => l.trim().replace(/^domain:/i, '').replace(/^full:/i, ''))
      .filter(l => l && !l.startsWith('#') && !l.startsWith('regexp:') && l.includes('.'));
    const combined = Array.from(new Set(['*.ir', ...IRAN_BUILTIN_DOMAINS, ...parsed.slice(0, 800)]));
    return { ok: true, domains: combined, source: 'Chocolate4U/Iran-v2ray-rules (Online)' };
  } catch (e) {
    return { ok: true, domains: IRAN_BUILTIN_DOMAINS, source: 'Chocolate4U/Iran-v2ray-rules (Offline Pack)' };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'APPLY_STATE') {
    applyFullState(msg.state).then(async () => {
      await chrome.storage.local.set({ omnigeo_state: msg.state });
      if (msg.state.enabled && msg.state.country) {
        chrome.action.setBadgeText({ text: msg.state.country.code });
        chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
      }
      if (msg.cleanData && chrome.browsingData) {
        await chrome.browsingData.remove({ since: 0 }, { cookies: true, cache: true, localStorage: true });
      }
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === 'DISABLE_AND_REVERT') {
    chrome.proxy.settings.clear({ scope: 'regular' });
    updateDynamicRules({ enabled: false });
    updateWebRTC(false);
    chrome.action.setBadgeText({ text: 'OFF' });
    chrome.action.setBadgeBackgroundColor({ color: '#64748b' });
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'TOGGLE_CURRENT_SITE') {
    chrome.storage.local.get(['omnigeo_state'], async (res) => {
      const state = res.omnigeo_state || {};
      const host = msg.host.toLowerCase().trim();
      const mode = state.splitMode || 'all_except_bypass';
      if (mode === 'only_include') {
        const list = new Set(state.includeDomains || []);
        if (list.has(host)) list.delete(host); else list.add(host);
        state.includeDomains = Array.from(list);
      } else {
        const list = new Set(state.bypassDomains || []);
        if (list.has(host)) list.delete(host); else list.add(host);
        state.bypassDomains = Array.from(list);
      }
      await chrome.storage.local.set({ omnigeo_state: state });
      if (state.enabled) await applyFullState(state);
      sendResponse({ ok: true, state });
    });
    return true;
  }

  if (msg.type === 'IMPORT_IRAN_RULES') {
    fetchChocolate4UIranRules().then(sendResponse);
    return true;
  }

  if (msg.type === 'CLEAN_SESSION_NOW') {
    chrome.browsingData.remove({ since: 0 }, { cookies: true, cache: true, localStorage: true }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }
});

chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(['omnigeo_state'], (res) => {
    if (res.omnigeo_state) applyFullState(res.omnigeo_state);
  });
});
