(function() {
  'use strict';
  let cfg = { enabled: false };
  try {
    const cached = sessionStorage.getItem('__OMNIGEO_CFG__');
    if (cached) cfg = JSON.parse(cached);
  } catch (e) {}

  window.addEventListener('message', (event) => {
    if (event.source === window && event.data && event.data.type === '__OMNIGEO_UPDATE__') {
      cfg = event.data.payload || { enabled: false };
    }
  });

  function isHostActiveForSpoof() {
    if (!cfg || !cfg.enabled) return false;
    const host = (window.location.hostname || '').toLowerCase();
    if (!host) return true;
    const mode = cfg.splitMode || 'all_except_bypass';
    const bypassList = (cfg.bypassDomains || []).map(d => d.toLowerCase().trim()).filter(Boolean);
    const includeList = (cfg.includeDomains || []).map(d => d.toLowerCase().trim()).filter(Boolean);

    const matches = (list) => list.some(rule => {
      if (rule === '*.ir' || rule === '.ir') return host.endsWith('.ir') || host === 'ir';
      const clean = rule.replace(/^\*\./, '');
      return host === clean || host.endsWith('.' + clean);
    });

    if (mode === 'only_include') return matches(includeList);
    return !matches(bypassList);
  }

  const sessionSeed = (() => {
    let s = sessionStorage.getItem('__OMNIGEO_SEED__');
    if (!s) {
      s = String(Math.floor(Math.random() * 1000000) + 1);
      try { sessionStorage.setItem('__OMNIGEO_SEED__', s); } catch (e) {}
    }
    return parseInt(s, 10);
  })();

  function getJitteredCoords(lat, lng) {
    const dLat = ((sessionSeed % 100) - 50) * 0.000003;
    const dLng = (((sessionSeed >> 3) % 100) - 50) * 0.000003;
    return {
      latitude: Number((lat + dLat).toFixed(6)),
      longitude: Number((lng + dLng).toFixed(6)),
      accuracy: 16 + (sessionSeed % 14),
      altitude: null, altitudeAccuracy: null, heading: null, speed: null
    };
  }

  const origGetPos = navigator.geolocation.getCurrentPosition.bind(navigator.geolocation);
  const origWatchPos = navigator.geolocation.watchPosition.bind(navigator.geolocation);

  navigator.geolocation.getCurrentPosition = function(success, error, options) {
    if (isHostActiveForSpoof() && cfg.country) {
      const coords = getJitteredCoords(cfg.country.lat, cfg.country.lng);
      setTimeout(() => { if (typeof success === 'function') success({ coords, timestamp: Date.now() }); }, 35);
      return;
    }
    return origGetPos(success, error, options);
  };

  navigator.geolocation.watchPosition = function(success, error, options) {
    if (isHostActiveForSpoof() && cfg.country) {
      const coords = getJitteredCoords(cfg.country.lat, cfg.country.lng);
      const id = setInterval(() => { if (typeof success === 'function') success({ coords, timestamp: Date.now() }); }, 3000);
      setTimeout(() => { if (typeof success === 'function') success({ coords, timestamp: Date.now() }); }, 35);
      return id;
    }
    return origWatchPos(success, error, options);
  };

  const origLang = Object.getOwnPropertyDescriptor(Navigator.prototype, 'language');
  const origLangs = Object.getOwnPropertyDescriptor(Navigator.prototype, 'languages');
  const origCores = Object.getOwnPropertyDescriptor(Navigator.prototype, 'hardwareConcurrency');
  const origMem = Object.getOwnPropertyDescriptor(Navigator.prototype, 'deviceMemory');

  Object.defineProperty(Navigator.prototype, 'language', {
    get: function() { return (isHostActiveForSpoof() && cfg.country && cfg.country.lang) ? cfg.country.lang : (origLang ? origLang.get.call(this) : 'en-US'); },
    configurable: true
  });

  Object.defineProperty(Navigator.prototype, 'languages', {
    get: function() { return (isHostActiveForSpoof() && cfg.country && Array.isArray(cfg.country.langs)) ? Object.freeze([...cfg.country.langs]) : (origLangs ? origLangs.get.call(this) : ['en-US', 'en']); },
    configurable: true
  });

  Object.defineProperty(Navigator.prototype, 'hardwareConcurrency', {
    get: function() { return (isHostActiveForSpoof() && cfg.hwSpoof !== false) ? 8 : (origCores ? origCores.get.call(this) : 4); },
    configurable: true
  });

  if (origMem) {
    Object.defineProperty(Navigator.prototype, 'deviceMemory', {
      get: function() { return (isHostActiveForSpoof() && cfg.hwSpoof !== false) ? 8 : origMem.get.call(this); },
      configurable: true
    });
  }

  const OrigDTF = Intl.DateTimeFormat;
  const origResolved = OrigDTF.prototype.resolvedOptions;

  function calcOffset(timeZone, date) {
    try {
      const utc = new Date(date.toLocaleString('en-US', { timeZone: 'UTC' }));
      const tz = new Date(date.toLocaleString('en-US', { timeZone }));
      return Math.round((utc.getTime() - tz.getTime()) / 60000);
    } catch (e) { return 0; }
  }

  Intl.DateTimeFormat = function(locales, options) {
    if (isHostActiveForSpoof() && cfg.country) {
      const opts = Object.assign({}, options);
      if (!opts.timeZone) opts.timeZone = cfg.country.tz;
      return new OrigDTF(locales || cfg.country.lang, opts);
    }
    return new OrigDTF(locales, options);
  };
  Intl.DateTimeFormat.prototype = OrigDTF.prototype;
  Intl.DateTimeFormat.supportedLocalesOf = OrigDTF.supportedLocalesOf;

  OrigDTF.prototype.resolvedOptions = function() {
    const res = origResolved.call(this);
    if (isHostActiveForSpoof() && cfg.country) {
      res.timeZone = cfg.country.tz;
      res.locale = cfg.country.lang;
    }
    return res;
  };

  const origOffset = Date.prototype.getTimezoneOffset;
  Date.prototype.getTimezoneOffset = function() {
    return (isHostActiveForSpoof() && cfg.country && cfg.country.tz) ? calcOffset(cfg.country.tz, this) : origOffset.call(this);
  };

  const GPU_PROFILES = [
    { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon RX 6600 Direct3D11 vs_5_0 ps_5_0, D3D11)' }
  ];
  const chosenGpu = GPU_PROFILES[sessionSeed % GPU_PROFILES.length];

  function patchWebGL(proto) {
    if (!proto || !proto.getParameter) return;
    const origGetParam = proto.getParameter;
    proto.getParameter = function(param) {
      if (isHostActiveForSpoof() && cfg.hwSpoof !== false) {
        if (param === 37445) return chosenGpu.vendor;
        if (param === 37446) return chosenGpu.renderer;
      }
      return origGetParam.apply(this, arguments);
    };
  }
  if (typeof WebGLRenderingContext !== 'undefined') patchWebGL(WebGLRenderingContext.prototype);
  if (typeof WebGL2RenderingContext !== 'undefined') patchWebGL(WebGL2RenderingContext.prototype);

  if (typeof HTMLCanvasElement !== 'undefined') {
    const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
    HTMLCanvasElement.prototype.toDataURL = function(...args) {
      if (isHostActiveForSpoof() && cfg.fpShield !== false && this.width > 16 && this.height > 16) {
        try {
          const ctx = this.getContext('2d');
          if (ctx) {
            const imgData = ctx.getImageData(0, 0, 2, 2);
            imgData.data[0] = (imgData.data[0] ^ (sessionSeed & 3)) & 255;
            ctx.putImageData(imgData, 0, 0);
          }
        } catch (e) {}
      }
      return origToDataURL.apply(this, args);
    };
  }

  if (typeof AudioBuffer !== 'undefined') {
    const origGetChannelData = AudioBuffer.prototype.getChannelData;
    AudioBuffer.prototype.getChannelData = function(...args) {
      const data = origGetChannelData.apply(this, args);
      if (isHostActiveForSpoof() && cfg.fpShield !== false && data && data.length > 0) {
        data[0] = data[0] + ((sessionSeed % 10) * 1e-7);
      }
      return data;
    };
  }

  if (typeof Element !== 'undefined' && Element.prototype.getBoundingClientRect) {
    const origRect = Element.prototype.getBoundingClientRect;
    Element.prototype.getBoundingClientRect = function() {
      const rect = origRect.apply(this, arguments);
      if (isHostActiveForSpoof() && cfg.fpShield !== false) {
        const jitter = ((sessionSeed % 5) - 2) * 0.00001;
        return new DOMRect(rect.x + jitter, rect.y + jitter, rect.width, rect.height);
      }
      return rect;
    };
  }
})();
