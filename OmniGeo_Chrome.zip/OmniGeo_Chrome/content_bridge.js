(function() {
  function syncConfig() {
    chrome.storage.local.get(['omnigeo_state'], (res) => {
      const state = res.omnigeo_state || { enabled: false };
      try { sessionStorage.setItem('__OMNIGEO_CFG__', JSON.stringify(state)); } catch (e) {}
      window.postMessage({ type: '__OMNIGEO_UPDATE__', payload: state }, '*');
    });
  }
  syncConfig();
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.omnigeo_state) syncConfig();
  });
})();
