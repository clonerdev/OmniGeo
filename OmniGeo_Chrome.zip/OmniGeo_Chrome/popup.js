const i18n = {
  fa: {
    subtitle: 'نمایش زنده موقعیت و هماهنگی با VPN سیستم',
    youAreIn: 'موقعیت فعلی:',
    connectedTo: 'هماهنگ‌شده با:',
    refreshBtn: 'به‌روزرسانی',
    ipLabel: 'آدرس IP',
    tzLabel: 'منطقه زمانی',
    locLabel: 'مختصات و زبان',
    tabLocation: '🌍 موقعیت و VPN',
    tabSplit: '🔀 تفکیک سایت‌ها',
    tabShield: '🛡️ اثر انگشت',
    selectCountry: 'کشور و شهر مقصد',
    searchPlaceholder: 'جستجوی شهر یا کشور...',
    ipModeTitle: 'روش تغییر IP',
    modeSystemVpn: 'VPN سیستم (هماهنگی GPS، زبان و اثر انگشت با VPN ویندوز)',
    modeDirectProxy: 'پراکسی مستقیم مرورگر (SOCKS5 / HTTPS / HTTP)',
    splitModeTitle: 'قانون عبور ترافیک سایت‌ها (Split Tunneling)',
    splitBypass: 'همه سایت‌ها فعال، بجز لیست استثنا (Bypass)',
    splitInclude: 'فقط سایت‌های داخل لیست فعال (بقیه مستقیم)',
    openPanelBtn: 'باز کردن پنل کامل تنظیمات',
    shieldOptions: 'تنظیمات ضد اثر انگشت و امنیت',
    fpShieldLabel: 'محافظت Canvas، صدا و جلوگیری از نشت WebRTC',
    hwSpoofLabel: 'مخفی‌سازی مدل کارت گرافیک (WebGL) و سخت‌افزار',
    trackerLabel: 'مسدودسازی ردیاب‌های شناسایی هویت',
    autoCleanLabel: 'پاکسازی کوکی‌ها هنگام تغییر کشور',
    connectBtn: 'اتصال',
    disconnectBtn: 'قطع اتصال',
    cleanBtn: 'پاکسازی',
    step1: 'در حال همگام‌سازی موقعیت، زبان و اثر انگشت...',
    step3Ok: '✅ فعال شد! مرورگر با موقعیت انتخابی هماهنگ گردید.'
  },
  en: {
    subtitle: 'Live Geo-Locator & System VPN Sync',
    youAreIn: 'Current location:',
    connectedTo: 'Synced with:',
    refreshBtn: 'Refresh',
    ipLabel: 'IP Address',
    tzLabel: 'Timezone',
    locLabel: 'Coords & Locale',
    tabLocation: '🌍 Location & VPN',
    tabSplit: '🔀 Split Tunneling',
    tabShield: '🛡️ Fingerprint',
    selectCountry: 'Target Country & City',
    searchPlaceholder: 'Search city or country...',
    ipModeTitle: 'IP Routing Mode',
    modeSystemVpn: 'System VPN (Sync GPS, Language & Fingerprint with OS VPN)',
    modeDirectProxy: 'Direct Browser Proxy (SOCKS5 / HTTPS / HTTP)',
    splitModeTitle: 'Per-Site Traffic Routing (Split Tunneling)',
    splitBypass: 'Active on all sites EXCEPT bypass list',
    splitInclude: 'Active ONLY on sites in include list',
    openPanelBtn: 'Open Full Settings Panel',
    shieldOptions: 'Anti-Fingerprint & Security Settings',
    fpShieldLabel: 'Canvas, Audio & WebRTC Leak Protection',
    hwSpoofLabel: 'Mask WebGL GPU & Hardware Specs',
    trackerLabel: 'Block Identity Tracking Scripts',
    autoCleanLabel: 'Clear cookies when switching country',
    connectBtn: 'Connect',
    disconnectBtn: 'Disconnect',
    cleanBtn: 'Clean',
    step1: 'Syncing GPS, timezone, locale & anti-fingerprint...',
    step3Ok: '✅ Active! Browser synced with selected location.'
  }
};

function codeToFlagEmoji(code) {
  return code.toUpperCase().replace(/./g, char => String.fromCodePoint(127397 + char.charCodeAt()));
}

let allCountries = [];
let globe = null;
let currentTabHostname = '';
let detectedOrigin = { lat: 52.52, lng: 13.405, code: 'DE', city: 'Berlin', label: '🇩🇪 Berlin' };

let currentState = {
  enabled: false,
  theme: 'light',
  uiLang: 'fa',
  countryId: 'de-ber',
  ipMode: 'system_vpn',
  proxy: { scheme: 'socks5', host: '', port: '10808' },
  splitMode: 'all_except_bypass',
  bypassDomains: ['*.ir', 'shaparak.ir', 'digikala.com'],
  includeDomains: ['youtube.com', 'google.com', 'x.com'],
  fpShield: true,
  hwSpoof: true,
  blockTrackers: true,
  autoClean: false
};

async function syncTruthfulLiveLocation() {
  const t = i18n[currentState.uiLang];
  const sysTz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  const sysLang = navigator.language || 'en-US';
  const pill = document.getElementById('statusPill');
  const statusEl = document.getElementById('statusLabelVal');

  try {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 4500);
    const res = await fetch('https://ipwho.is/', { signal: ctrl.signal, cache: 'no-store' });
    const data = await res.json();
    if (data && data.success) {
      const code = data.country_code || 'UN';
      const city = data.city || data.country || 'Unknown';
      const lat = Number(data.latitude);
      const lng = Number(data.longitude);
      const flag = codeToFlagEmoji(code);

      if (!currentState.enabled) {
        detectedOrigin = { lat, lng, code, city, label: `${flag} ${city}` };
        globe.flyTo(lat, lng, `${flag} ${city}`, code, false, detectedOrigin);
        pill.classList.remove('active', 'error');
        statusEl.textContent = `${t.youAreIn} ${city} (${code})`;
      } else {
        const target = currentState.country || { lat, lng, code, city_fa: city, city_en: city, tz: sysTz, lang: sysLang };
        const tCity = currentState.uiLang === 'fa' ? target.city_fa : target.city_en;
        globe.flyTo(target.lat, target.lng, `${codeToFlagEmoji(target.code)} ${tCity}`, target.code, true, detectedOrigin);
        pill.classList.remove('error');
        pill.classList.add('active');
        statusEl.textContent = `${t.connectedTo} ${tCity} (${target.code})`;
      }

      document.getElementById('hudIpGeo').textContent = `${data.ip} (${code})`;
      document.getElementById('hudTz').textContent = currentState.enabled && currentState.country ? currentState.country.tz : (data.timezone?.id || sysTz);
      const dispLat = currentState.enabled && currentState.country ? currentState.country.lat : lat;
      const dispLng = currentState.enabled && currentState.country ? currentState.country.lng : lng;
      const dispLang = currentState.enabled && currentState.country ? currentState.country.lang : sysLang;
      document.getElementById('hudGpsLocale').textContent = `${dispLat.toFixed(2)}, ${dispLng.toFixed(2)} • ${dispLang}`;
      return { ok: true };
    }
  } catch (e) {}

  if (currentState.enabled && currentState.country) {
    const c = currentState.country;
    const tCity = currentState.uiLang === 'fa' ? c.city_fa : c.city_en;
    globe.flyTo(c.lat, c.lng, `${codeToFlagEmoji(c.code)} ${tCity}`, c.code, true, detectedOrigin);
    pill.classList.add('active');
    statusEl.textContent = `${t.connectedTo} ${tCity} (${c.code})`;
    document.getElementById('hudTz').textContent = c.tz;
    document.getElementById('hudGpsLocale').textContent = `${c.lat.toFixed(2)}, ${c.lng.toFixed(2)} • ${c.lang}`;
  } else {
    const tzCity = allCountries.find(c => c.tz === sysTz);
    if (tzCity) {
      const cityName = currentState.uiLang === 'fa' ? tzCity.city_fa : tzCity.city_en;
      const pinLabel = `${codeToFlagEmoji(tzCity.code)} ${cityName}`;
      detectedOrigin = { lat: tzCity.lat, lng: tzCity.lng, code: tzCity.code, city: cityName, label: pinLabel };
      globe.flyTo(tzCity.lat, tzCity.lng, pinLabel, tzCity.code, false, detectedOrigin);
      statusEl.textContent = `${t.youAreIn} ${cityName}`;
    }
  }
  document.getElementById('hudIpGeo').textContent = 'System Network';
  return { ok: true };
}

function updateCurrentTabBanner() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const bar = document.getElementById('siteRuleBar');
    if (!tabs || !tabs[0] || !tabs[0].url || !tabs[0].url.startsWith('http')) {
      bar.classList.add('hidden');
      return;
    }
    bar.classList.remove('hidden');
    const urlObj = new URL(tabs[0].url);
    currentTabHostname = urlObj.hostname.toLowerCase();
    document.getElementById('currentTabHost').textContent = currentTabHostname;

    const statusEl = document.getElementById('currentTabRuleStatus');
    const btn = document.getElementById('toggleSiteRuleBtn');
    const isFa = currentState.uiLang === 'fa';

    if (currentState.splitMode === 'only_include') {
      const included = (currentState.includeDomains || []).includes(currentTabHostname);
      statusEl.textContent = included ? (isFa ? '✅ در لیست فعال است' : '✅ Included') : (isFa ? '⚪ مستقیم باز می‌شود' : '⚪ Direct');
      btn.textContent = included ? (isFa ? 'حذف از لیست' : 'Remove') : (isFa ? 'افزودن به لیست' : 'Include');
      btn.classList.toggle('bypassed', !included);
    } else {
      const bypassed = (currentState.bypassDomains || []).includes(currentTabHostname);
      statusEl.textContent = bypassed ? (isFa ? '⚠️ مستثنا شده (مستقیم)' : '⚠️ Excluded (Direct)') : (isFa ? '✅ هماهنگ‌سازی روی این سایت فعال است' : '✅ Active on this site');
      btn.textContent = bypassed ? (isFa ? 'لغو استثنا' : 'Re-enable') : (isFa ? 'استثنا کردن سایت' : 'Exclude Site');
      btn.classList.toggle('bypassed', bypassed);
    }
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  globe = new OmniGlobe3D(document.getElementById('earthCanvas'));

  const resp = await fetch(chrome.runtime.getURL('countries.json'));
  allCountries = await resp.json();

  chrome.storage.local.get(['omnigeo_state'], async (res) => {
    if (res.omnigeo_state) currentState = Object.assign(currentState, res.omnigeo_state);
    if (!['system_vpn', 'direct_proxy'].includes(currentState.ipMode)) {
      currentState.ipMode = 'system_vpn';
    }
    initUI();
    updateCurrentTabBanner();
    updateConnectButton(currentState.enabled);
    await syncTruthfulLiveLocation();
  });
});

function selectCountryItem(countryObj) {
  currentState.countryId = countryObj.id;
  document.getElementById('countrySelect').value = countryObj.id;
  document.getElementById('selectedFlagImg').src = chrome.runtime.getURL(countryObj.flag);
  document.getElementById('selectedCountryLabel').textContent = currentState.uiLang === 'fa'
    ? `${countryObj.name_fa} (${countryObj.code})`
    : `${countryObj.name_en} (${countryObj.code})`;
}

function renderCountries(filter) {
  const listEl = document.getElementById('countryOptionsList');
  const q = filter.trim().toLowerCase();
  listEl.innerHTML = '';

  const filtered = allCountries.filter((c) =>
    c.name_en.toLowerCase().includes(q) || c.name_fa.includes(q) || c.code.toLowerCase().includes(q)
  );

  filtered.forEach((c) => {
    const item = document.createElement('div');
    item.className = 'dropdown-item' + (c.id === currentState.countryId ? ' selected' : '');

    const flagImg = document.createElement('img');
    flagImg.src = chrome.runtime.getURL(c.flag);
    flagImg.className = 'flag-icon';
    flagImg.alt = c.code;

    const textSpan = document.createElement('span');
    textSpan.textContent = currentState.uiLang === 'fa'
      ? `${c.name_fa} (${c.code})`
      : `${c.name_en} (${c.code})`;

    item.appendChild(flagImg);
    item.appendChild(textSpan);

    item.addEventListener('click', () => {
      selectCountryItem(c);
      document.getElementById('countryDropdownMenu').classList.add('hidden');
      renderCountries(document.getElementById('countrySearch').value);
    });

    listEl.appendChild(item);
  });

  const activeC = allCountries.find(x => x.id === currentState.countryId) || allCountries[0];
  selectCountryItem(activeC);
}

function initUI() {
  applyTheme(currentState.theme || 'light');
  applyLanguage(currentState.uiLang || 'fa');

  document.getElementById('powerToggle').checked = currentState.enabled;
  document.getElementById('ipModeSelect').value = currentState.ipMode;
  document.getElementById('splitModeSelect').value = currentState.splitMode || 'all_except_bypass';

  if (currentState.proxy) {
    document.getElementById('proxyScheme').value = currentState.proxy.scheme || 'socks5';
    document.getElementById('proxyHost').value = currentState.proxy.host || '';
    document.getElementById('proxyPort').value = currentState.proxy.port || '10808';
  }

  document.getElementById('fpShieldCheck').checked = currentState.fpShield;
  document.getElementById('hwSpoofCheck').checked = currentState.hwSpoof !== false;
  document.getElementById('blockTrackersCheck').checked = currentState.blockTrackers !== false;
  document.getElementById('autoCleanCheck').checked = currentState.autoClean;

  syncDomainTextarea();
  renderCountries('');
  updateSubPanels();

  // Dropdown toggle
  const trigger = document.getElementById('countryDropdownTrigger');
  const menu = document.getElementById('countryDropdownMenu');
  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    menu.classList.toggle('hidden');
    if (!menu.classList.contains('hidden')) {
      document.getElementById('countrySearch').focus();
    }
  });
  document.addEventListener('click', (e) => {
    if (!document.getElementById('countryDropdown').contains(e.target)) {
      menu.classList.add('hidden');
    }
  });

  document.getElementById('openOptionsBtn').addEventListener('click', () => chrome.runtime.openOptionsPage());
  document.getElementById('openFullSettingsBtn').addEventListener('click', () => chrome.runtime.openOptionsPage());

  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
    });
  });

  document.getElementById('themeToggle').addEventListener('click', () => {
    currentState.theme = currentState.theme === 'light' ? 'dark' : 'light';
    applyTheme(currentState.theme);
    chrome.storage.local.set({ omnigeo_state: currentState });
  });

  document.getElementById('langToggle').addEventListener('click', () => {
    currentState.uiLang = currentState.uiLang === 'fa' ? 'en' : 'fa';
    applyLanguage(currentState.uiLang);
    renderCountries(document.getElementById('countrySearch').value);
    updateCurrentTabBanner();
    updateConnectButton(currentState.enabled);
  });

  document.getElementById('toggleSiteRuleBtn').addEventListener('click', () => {
    if (!currentTabHostname) return;
    chrome.runtime.sendMessage({ type: 'TOGGLE_CURRENT_SITE', host: currentTabHostname }, (res) => {
      if (res && res.state) {
        currentState = Object.assign(currentState, res.state);
        syncDomainTextarea();
        updateCurrentTabBanner();
      }
    });
  });

  document.getElementById('splitModeSelect').addEventListener('change', (e) => {
    currentState.splitMode = e.target.value;
    syncDomainTextarea();
    updateCurrentTabBanner();
  });

  document.getElementById('importIranRulesBtn').addEventListener('click', () => {
    const btn = document.getElementById('importIranRulesBtn');
    btn.textContent = '⏳...';
    chrome.runtime.sendMessage({ type: 'IMPORT_IRAN_RULES' }, (res) => {
      if (res && res.ok) {
        const merged = Array.from(new Set([...(currentState.bypassDomains || []), ...res.domains]));
        currentState.bypassDomains = merged;
        currentState.splitMode = 'all_except_bypass';
        document.getElementById('splitModeSelect').value = 'all_except_bypass';
        syncDomainTextarea();
        updateCurrentTabBanner();
        btn.textContent = `✓ (${merged.length})`;
      }
    });
  });

  document.getElementById('scanNowBtn').addEventListener('click', () => syncTruthfulLiveLocation());
  document.getElementById('countrySearch').addEventListener('input', (e) => renderCountries(e.target.value));

  document.getElementById('ipModeSelect').addEventListener('change', (e) => {
    currentState.ipMode = e.target.value;
    updateSubPanels();
  });

  document.getElementById('powerToggle').addEventListener('change', (e) => {
    if (e.target.checked) startConnectionFlow();
    else disconnectFlow();
  });

  document.getElementById('applyBtn').addEventListener('click', () => {
    if (currentState.enabled) disconnectFlow();
    else startConnectionFlow();
  });

  document.getElementById('cleanNowBtn').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'CLEAN_SESSION_NOW' }, () => {
      const t = i18n[currentState.uiLang];
      const btn = document.getElementById('cleanNowBtn');
      btn.textContent = '✓';
      setTimeout(() => { btn.textContent = t.cleanBtn; }, 1200);
    });
  });
}

function syncDomainTextarea() {
  const area = document.getElementById('splitDomainsInput');
  const countEl = document.getElementById('rulesCountText');
  const list = currentState.splitMode === 'only_include'
    ? (currentState.includeDomains || [])
    : (currentState.bypassDomains || []);
  area.value = list.join('\n');
  countEl.textContent = currentState.uiLang === 'fa'
    ? `تعداد دامنه‌های ثبت‌شده: ${list.length}`
    : `Registered domains: ${list.length}`;
}

async function startConnectionFlow() {
  const t = i18n[currentState.uiLang];
  const stepBox = document.getElementById('connStepBox');
  const stepText = document.getElementById('stepLineText');

  stepBox.className = 'conn-steps';
  stepBox.classList.remove('hidden');
  stepText.textContent = t.step1;

  const country = allCountries.find((c) => c.id === document.getElementById('countrySelect').value) || allCountries[0];
  const pendingState = Object.assign({}, currentState, {
    enabled: true,
    countryId: country.id,
    country: country,
    ipMode: document.getElementById('ipModeSelect').value,
    proxy: {
      scheme: document.getElementById('proxyScheme').value,
      host: document.getElementById('proxyHost').value,
      port: document.getElementById('proxyPort').value
    },
    fpShield: document.getElementById('fpShieldCheck').checked,
    hwSpoof: document.getElementById('hwSpoofCheck').checked,
    blockTrackers: document.getElementById('blockTrackersCheck').checked,
    autoClean: document.getElementById('autoCleanCheck').checked
  });

  const editedDomains = document.getElementById('splitDomainsInput').value
    .split('\n').map(s => s.trim()).filter(Boolean);
  if (pendingState.splitMode === 'only_include') pendingState.includeDomains = editedDomains;
  else pendingState.bypassDomains = editedDomains;

  await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'APPLY_STATE', state: pendingState, cleanData: pendingState.autoClean }, resolve);
  });

  currentState = pendingState;
  document.getElementById('powerToggle').checked = true;
  updateConnectButton(true);
  await syncTruthfulLiveLocation();

  stepBox.className = 'conn-steps success';
  stepText.textContent = t.step3Ok;
}

function disconnectFlow() {
  currentState.enabled = false;
  document.getElementById('powerToggle').checked = false;
  document.getElementById('connStepBox').classList.add('hidden');
  updateConnectButton(false);

  chrome.storage.local.set({ omnigeo_state: currentState }, () => {
    chrome.runtime.sendMessage({ type: 'DISABLE_AND_REVERT' }, async () => {
      await syncTruthfulLiveLocation();
    });
  });
}

function updateConnectButton(isConnected) {
  const t = i18n[currentState.uiLang];
  const btn = document.getElementById('applyBtn');
  btn.textContent = isConnected ? t.disconnectBtn : t.connectBtn;
  btn.style.background = isConnected ? 'linear-gradient(135deg, #ef4444, #dc2626)' : 'linear-gradient(135deg, #2563eb, #10b981)';
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  document.getElementById('themeToggle').textContent = theme === 'light' ? '🌙' : '☀️';
}

function applyLanguage(lang) {
  const t = i18n[lang];
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
  document.getElementById('langToggle').textContent = lang === 'fa' ? 'EN' : 'فا';
  document.getElementById('subtitleText').textContent = t.subtitle;
  document.getElementById('countrySearch').placeholder = t.searchPlaceholder;
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    if (t[key]) el.textContent = t[key];
  });
  updateConnectButton(currentState.enabled);
}

function updateSubPanels() {
  const mode = document.getElementById('ipModeSelect').value;
  document.getElementById('directProxyBox').classList.toggle('hidden', mode !== 'direct_proxy');
}
