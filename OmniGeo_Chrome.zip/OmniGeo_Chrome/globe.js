class OmniGlobe3D {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.dpr = window.devicePixelRatio || 1;
    this.width = 384;
    this.height = 166;
    this.canvas.width = this.width * this.dpr;
    this.canvas.height = this.height * this.dpr;
    this.ctx.scale(this.dpr, this.dpr);

    this.rotLng = 13.4;
    this.rotLat = 45.0;
    this.targetLng = 13.4;
    this.targetLat = 45.0;

    this.originPoint = null;
    this.activePoint = null;
    this.isSpoofed = false;
    this.pulsePhase = 0;
    this.isDragging = false;
    this.lastMouse = { x: 0, y: 0 };

    this.continents = [
      [[-168,65],[-140,70],[-95,72],[-60,62],[-55,47],[-70,41],[-81,25],[-97,26],[-105,20],[-85,10],[-79,9],[-92,15],[-115,31],[-124,48],[-150,60],[-168,65]],
      [[-78,10],[-60,7],[-35,-6],[-39,-18],[-53,-33],[-68,-54],[-75,-48],[-71,-18],[-81,-5],[-78,10]],
      [[-9,36],[-9,43],[-4,48],[2,51],[9,54],[10,58],[5,61],[18,69],[28,71],[42,67],[58,68],[60,52],[40,45],[29,41],[23,37],[15,38],[12,44],[3,43],[-9,36]],
      [[-17,15],[-5,35],[10,37],[32,31],[43,12],[51,11],[40,-12],[35,-24],[20,-34],[15,-28],[12,-6],[9,4],[-8,5],[-17,15]],
      [[29,41],[42,42],[55,38],[68,24],[77,8],[88,22],[102,2],[109,18],[121,25],[122,40],[135,35],[142,45],[160,55],[178,66],[130,71],[90,75],[60,68],[60,52],[40,45],[29,41]],
      [[114,-22],[130,-12],[142,-11],[153,-28],[148,-38],[136,-35],[115,-34],[114,-22]],
      [[-52,60],[-42,60],[-20,70],[-25,82],[-60,81],[-52,60]]
    ];

    this.bindEvents();
    this.startLoop();
  }

  bindEvents() {
    this.canvas.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.lastMouse = { x: e.clientX, y: e.clientY };
    });
    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      const dx = e.clientX - this.lastMouse.x;
      const dy = e.clientY - this.lastMouse.y;
      this.lastMouse = { x: e.clientX, y: e.clientY };
      this.rotLng += dx * 0.45;
      this.rotLat = Math.max(-75, Math.min(75, this.rotLat + dy * 0.45));
      this.targetLng = this.rotLng;
      this.targetLat = this.rotLat;
    });
    window.addEventListener('mouseup', () => { this.isDragging = false; });
  }

  flyTo(lat, lng, label, code, isSpoofed = false, origin = null) {
    this.targetLat = lat;
    this.targetLng = lng;
    this.activePoint = { lat, lng, label, code };
    this.isSpoofed = isSpoofed;
    if (origin) this.originPoint = origin;
  }

  project(lat, lng) {
    const rad = Math.PI / 180;
    const phi = lat * rad;
    const lam = lng * rad;
    const phi0 = this.rotLat * rad;
    const lam0 = this.rotLng * rad;

    const cosPhi = Math.cos(phi);
    const sinPhi = Math.sin(phi);
    const cosPhi0 = Math.cos(phi0);
    const sinPhi0 = Math.sin(phi0);
    const dLam = lam - lam0;
    const cosDLam = Math.cos(dLam);

    const cosC = sinPhi0 * sinPhi + cosPhi0 * cosPhi * cosDLam;
    const R = 70;
    const cx = this.width / 2;
    const cy = this.height / 2 + 2;

    const x = cx + R * cosPhi * Math.sin(dLam);
    const y = cy - R * (cosPhi0 * sinPhi - sinPhi0 * cosPhi * cosDLam);
    return { x, y, visible: cosC >= 0 };
  }

  drawPin(lat, lng, color, label, isTarget) {
    const p = this.project(lat, lng);
    if (!p.visible) return;
    const ctx = this.ctx;

    const pulseR = 6 + ((this.pulsePhase % 1) * (isTarget ? 18 : 13));
    const pulseAlpha = Math.max(0, 1 - (this.pulsePhase % 1));
    ctx.beginPath();
    ctx.arc(p.x, p.y, pulseR, 0, Math.PI * 2);
    ctx.strokeStyle = isTarget ? `rgba(16, 185, 129, ${pulseAlpha * 0.9})` : `rgba(37, 99, 235, ${pulseAlpha * 0.85})`;
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.bezierCurveTo(-8, -10, -10, -20, 0, -22);
    ctx.bezierCurveTo(10, -20, 8, -10, 0, 0);
    ctx.fillStyle = isTarget ? '#10b981' : '#2563eb';
    ctx.fill();
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = '#ffffff';
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(0, -14, 3.2, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    ctx.restore();

    if (label) {
      ctx.font = 'bold 10.5px Segoe UI, Tahoma, sans-serif';
      const tw = ctx.measureText(label).width;
      const bx = Math.max(6, Math.min(this.width - tw - 20, p.x - tw / 2 - 7));
      const by = Math.max(4, p.y - 42);
      ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      ctx.beginPath();
      ctx.roundRect(bx, by, tw + 14, 18, 7);
      ctx.fill();
      ctx.strokeStyle = isTarget ? '#10b981' : '#38bdf8';
      ctx.lineWidth = 1.1;
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText(label, bx + (tw + 14) / 2, by + 12.5);
    }
  }

  drawArc(p1, p2) {
    if (!p1 || !p2) return;
    const ctx = this.ctx;
    const steps = 30;
    ctx.beginPath();
    let started = false;
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const lat = p1.lat + (p2.lat - p1.lat) * t + Math.sin(t * Math.PI) * 14;
      const lng = p1.lng + (p2.lng - p1.lng) * t;
      const pt = this.project(lat, lng);
      if (pt.visible) {
        if (!started) { ctx.moveTo(pt.x, pt.y); started = true; }
        else { ctx.lineTo(pt.x, pt.y); }
      } else { started = false; }
    }
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.85)';
    ctx.setLineDash([4, 3]);
    ctx.lineWidth = 1.8;
    ctx.stroke();
    ctx.setLineDash([]);
  }

  render() {
    const ctx = this.ctx;
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    ctx.clearRect(0, 0, this.width, this.height);

    const cx = this.width / 2;
    const cy = this.height / 2 + 2;
    const R = 70;

    const glow = ctx.createRadialGradient(cx, cy, R * 0.85, cx, cy, R * 1.24);
    glow.addColorStop(0, isDark ? 'rgba(56, 189, 248, 0.25)' : 'rgba(37, 99, 235, 0.16)');
    glow.addColorStop(1, 'rgba(56, 189, 248, 0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(cx, cy, R * 1.24, 0, Math.PI * 2);
    ctx.fill();

    const ocean = ctx.createRadialGradient(cx - 22, cy - 22, 8, cx, cy, R);
    if (isDark) {
      ocean.addColorStop(0, '#1e3a8a');
      ocean.addColorStop(0.7, '#0f172a');
      ocean.addColorStop(1, '#020617');
    } else {
      ocean.addColorStop(0, '#38bdf8');
      ocean.addColorStop(0.65, '#0284c7');
      ocean.addColorStop(1, '#1e3a8a');
    }
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.fillStyle = ocean;
    ctx.fill();

    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.clip();

    ctx.strokeStyle = isDark ? 'rgba(148, 163, 184, 0.16)' : 'rgba(255, 255, 255, 0.22)';
    ctx.lineWidth = 0.7;
    for (let lat = -60; lat <= 60; lat += 30) {
      ctx.beginPath();
      let first = true;
      for (let lng = -180; lng <= 180; lng += 10) {
        const pt = this.project(lat, lng);
        if (pt.visible) {
          if (first) { ctx.moveTo(pt.x, pt.y); first = false; }
          else ctx.lineTo(pt.x, pt.y);
        } else { first = true; }
      }
      ctx.stroke();
    }
    for (let lng = -180; lng < 180; lng += 30) {
      ctx.beginPath();
      let first = true;
      for (let lat = -85; lat <= 85; lat += 10) {
        const pt = this.project(lat, lng);
        if (pt.visible) {
          if (first) { ctx.moveTo(pt.x, pt.y); first = false; }
          else ctx.lineTo(pt.x, pt.y);
        } else { first = true; }
      }
      ctx.stroke();
    }

    ctx.fillStyle = isDark ? '#334155' : '#e2e8f0';
    ctx.strokeStyle = isDark ? '#64748b' : '#ffffff';
    ctx.lineWidth = 0.9;
    for (const poly of this.continents) {
      ctx.beginPath();
      let started = false;
      for (const [lng, lat] of poly) {
        const pt = this.project(lat, lng);
        if (!started) { ctx.moveTo(pt.x, pt.y); started = true; }
        else ctx.lineTo(pt.x, pt.y);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
    ctx.restore();

    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.strokeStyle = isDark ? 'rgba(56, 189, 248, 0.45)' : 'rgba(255, 255, 255, 0.65)';
    ctx.lineWidth = 1.4;
    ctx.stroke();

    if (this.isSpoofed && this.originPoint && this.activePoint) {
      this.drawArc(this.originPoint, this.activePoint);
      this.drawPin(this.originPoint.lat, this.originPoint.lng, '#2563eb', this.originPoint.code, false);
    }

    if (this.activePoint) {
      this.drawPin(
        this.activePoint.lat,
        this.activePoint.lng,
        this.isSpoofed ? '#10b981' : '#2563eb',
        this.activePoint.label,
        this.isSpoofed
      );
    }
  }

  startLoop() {
    const tick = () => {
      if (!this.isDragging) {
        let dLng = this.targetLng - this.rotLng;
        while (dLng > 180) dLng -= 360;
        while (dLng < -180) dLng += 360;
        this.rotLng += dLng * 0.12;
        this.rotLat += (this.targetLat - this.rotLat) * 0.12;
      }
      this.pulsePhase += 0.018;
      this.render();
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }
}
