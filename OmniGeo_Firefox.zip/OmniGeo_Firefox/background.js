const api = typeof browser !== 'undefined' ? browser : chrome;
let activeState = { enabled: false, ipMode: 'system_vpn', splitMode: 'all_except_bypass', bypassDomains: ['*.ir'], includeDomains: [] };

const IRAN_BUILTIN_DOMAINS = [
  '*.ir', 'shaparak.ir', 'bmi.ir', 'mellatbank.com', 'bankmellat.ir', 'tejaratbank.ir',
  'bsi.ir', 'banksepah.ir', 'bpi.ir', 'sb24.ir', 'parsian-bank.ir', 'refah-bank.ir',
  'snapp.ir', 'tapsi.ir', 'digikala.com', 'divar.ir', 'sheypoor.com', 'aparat.com',
  'filimo.com', 'namava.ir', 'telewebion.com', 'rubika.ir', 'eitaa.com', 'bale.ai'
];

function matchDomain(host, list) {
  host = (host || '').toLowerCase();
  for (const rule of (list || [])) {
    const r = rule.toLowerCase().trim();
    if (!r) continue;
    if (r === '*.ir' || r === '.ir') {
      if (host.endsWith('.ir') || host === 'ir') return true;
    } else {
      const clean = r.replace(/^\*\./, '');
      if (host === clean || host.endsWith('.' + clean)) return true;
    }
  }
  return false;
}

if (api.proxy && api.proxy.onRequest) {
  api.proxy.onRequest.addListener((requestInfo) => {
    if (!activeState.enabled || activeState.ipMode !== 'direct_proxy' || !activeState.proxy || !activeState.proxy.host) {
      return { type: 'direct' };
    }
    const url = new URL(requestInfo.url);
    const host = url.hostname.toLowerCase();
    if (host === '127.0.0.1' || host === 'localhost') return { type: 'direct' };

    const sch = (activeState.proxy.scheme || 'socks5').toLowerCase();
    const proxyObj = {
      type: sch.startsWith('socks') ? 'socks' : (sch === 'https' ? 'https' : 'http'),
      host: activeState.proxy.host.trim(),
      port: parseInt(activeState.proxy.port, 10) || 10808,
      proxyDNS: true
    };

    if (activeState.splitMode === 'only_include') {
      return matchDomain(host, activeState.includeDomains) ? proxyObj : { type: 'direct' };
    }
    return matchDomain(host, activeState.bypassDomains) ? { type: 'direct' } : proxyObj;
  }, { urls: ['<all_urls>'] });
}

api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'APPLY_STATE') {
    activeState = Object.assign({}, msg.state);
    api.storage.local.set({ omnigeo_state: msg.state }).then(async () => {
      if (msg.cleanData && api.browsingData) {
        await api.browsingData.remove({ since: 0 }, { cookies: true, cache: true, localStorage: true });
      }
      sendResponse({ ok: true });
    });
    return true;
  }
  if (msg.type === 'DISABLE_AND_REVERT') {
    activeState.enabled = false;
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'TOGGLE_CURRENT_SITE') {
    api.storage.local.get(['omnigeo_state']).then(async (res) => {
      const state = res.omnigeo_state || {};
      const host = msg.host.toLowerCase().trim();
      const mode = state.splitMode || 'all_except_bypass';
      if (mode === 'only_include') {
        const list = new Set(state.includeDomains || []);
        if (list.has(host)) list.delete(host); else list.add(host);
        state.includeDomains = Array.from(list);
      } else {
        const list = new Set(state.bypassDomains || []);
        if (list.has(host)) list.delete(host); else list.add(host);
        state.bypassDomains = Array.from(list);
      }
      await api.storage.local.set({ omnigeo_state: state });
      activeState = Object.assign({}, state);
      sendResponse({ ok: true, state });
    });
    return true;
  }
  if (msg.type === 'IMPORT_IRAN_RULES') {
    sendResponse({ ok: true, domains: IRAN_BUILTIN_DOMAINS, source: 'Iran Rules Pack' });
    return true;
  }
  if (msg.type === 'CLEAN_SESSION_NOW') {
    if (api.browsingData) {
      api.browsingData.remove({ since: 0 }, { cookies: true, cache: true, localStorage: true }).then(() => sendResponse({ ok: true }));
    } else {
      sendResponse({ ok: true });
    }
    return true;
  }
});

api.storage.local.get(['omnigeo_state']).then((res) => {
  if (res.omnigeo_state) activeState = Object.assign({}, res.omnigeo_state);
});
