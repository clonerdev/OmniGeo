if (typeof browser !== 'undefined' && typeof chrome === 'undefined') { window.chrome = browser; }
document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get(['omnigeo_state'], (res) => {
    const state = res.omnigeo_state || {};
    document.getElementById('bypassArea').value = (state.bypassDomains || ['*.ir', 'shaparak.ir']).join('\n');
    document.getElementById('includeArea').value = (state.includeDomains || ['youtube.com', 'google.com']).join('\n');
  });

  document.getElementById('importIranBtn').addEventListener('click', () => {
    const btn = document.getElementById('importIranBtn');
    btn.textContent = '⏳ در حال دریافت لیست...';
    chrome.runtime.sendMessage({ type: 'IMPORT_IRAN_RULES' }, (res) => {
      if (res && res.ok) {
        const cur = document.getElementById('bypassArea').value.split('\n').map(s => s.trim()).filter(Boolean);
        const merged = Array.from(new Set([...cur, ...res.domains]));
        document.getElementById('bypassArea').value = merged.join('\n');
        btn.textContent = `✓ ${merged.length} دامنه ایران اضافه شد`;
      }
    });
  });

  document.getElementById('saveAllBtn').addEventListener('click', () => {
    chrome.storage.local.get(['omnigeo_state'], (res) => {
      const state = res.omnigeo_state || {};
      state.bypassDomains = document.getElementById('bypassArea').value.split('\n').map(s => s.trim()).filter(Boolean);
      state.includeDomains = document.getElementById('includeArea').value.split('\n').map(s => s.trim()).filter(Boolean);
      chrome.runtime.sendMessage({ type: 'APPLY_STATE', state }, () => {
        document.getElementById('saveMsg').textContent = '✅ تنظیمات ذخیره و اعمال شد!';
        setTimeout(() => { document.getElementById('saveMsg').textContent = ''; }, 2500);
      });
    });
  });

  document.getElementById('exportRulesBtn').addEventListener('click', () => {
    chrome.storage.local.get(['omnigeo_state'], (res) => {
      const blob = new Blob([JSON.stringify(res.omnigeo_state || {}, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'omnigeo-v1-rules.json';
      a.click();
    });
  });
});
